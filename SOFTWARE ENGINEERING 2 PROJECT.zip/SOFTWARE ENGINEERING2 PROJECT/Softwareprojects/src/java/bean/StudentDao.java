/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.ArrayList;
import java.sql.*;
import java.util.Collections;

/**
 *
 * @author SBONGA
 */
public class StudentDao {

    public static ArrayList<String> process(String userid) {
        
        ArrayList<String> illegalModules = new ArrayList<>();
        ArrayList<String> modules = new ArrayList<>();
        ArrayList<String> prerequisite = new ArrayList<>();

        Connection con;
        try {
            PreparedStatement pst;
            ResultSet rs;

            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/softwaredatabase?zeroDateTimeBehavior=convertToNull", "root", "");

            String query = "select YearOfStudy from student where studentid='" + userid + "'";
            Statement st = con.createStatement();
            rs = st.executeQuery(query);
            int year = 0;
            if (rs.next()) {
                year = rs.getInt("YearOfStudy");
            }
            if (year==0) throw new Exception("Year=0");
            // Module for that year sem2
            query = "select ModuleCode from addmodule where Year=" + year + " and Semester=2";
            st = con.createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                modules.add(rs.getString("ModuleCode"));
            }
            if (modules.isEmpty()) throw new Exception("No record found.");
            
            // Search for ID in Module
            for (String mod: modules) {
                query = "select * from "+mod+" where StudentID='" + userid + "'";
                st = con.createStatement();
                rs = st.executeQuery(query);
                if (!rs.next()) {
                    modules.remove(mod);
                }
            }
            
            // Get all prerequisites
            for (String mod: modules) {
                String premod = null;  // Current module's prerequisite modules
                query = "select PreRequisite from addmodule where ModuleCode='" + mod + "'";
                st = con.createStatement();
                rs = st.executeQuery(query);
                if (rs.next()) {
                    premod = rs.getString("PreRequisite");
                }
                if (premod != null) {
                    Collections.addAll(prerequisite, premod.split(","));
                    // Search for ID in Module
                    for (String mod2: prerequisite) {
                        query = "select Marks from "+mod2+" where StudentID='" + userid + "'";
                        st = con.createStatement();
                        rs = st.executeQuery(query);
                        if (rs.next()) {
                            int mark = rs.getInt("Marks");
                            if (mark < 50)
                                illegalModules.add(mod);
                        }
                    }
                }
            }
            con.close();
        } catch (Exception e) {
            illegalModules.add(e.getMessage());
        }
        
        return illegalModules ;
    }
}
