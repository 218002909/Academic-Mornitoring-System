/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.io.IOException;
import java.io.PrintWriter;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;
import java.sql.*;

public class login extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String name = request.getParameter("username");
            String pass = request.getParameter("password");
            //Connection con;
            //Connection con = null;
            PreparedStatement pre;
            ResultSet res;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con =(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/softwaredatabase?zeroDateTimeBehavior=convertToNull","root","");
                String query = "SELECT * FROM userlogin where username='"+name+"' and password='"+pass+"'";
                pre =con.prepareStatement(query);
                pre.executeQuery();
                res = pre.getResultSet();
                if(res.next()){
                    String username = res.getString("username");
                    String password = res.getString("password");
                    if(username.equals(name) && password.equals(pass)){
                        response.sendRedirect("StudentPage.jsp?username="+username);
                    }
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "invalid");
            }
            /*MyDb db = new MyDb();
            Connection con = db.getCon();*/
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

}
